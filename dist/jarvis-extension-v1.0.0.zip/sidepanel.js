// JARVIS — Side Panel Logic

(function () {
  'use strict';

  // ---------------------------------------------------------------------------
  // DOM References
  // ---------------------------------------------------------------------------

  const $ = (sel) => document.querySelector(sel);
  const $$ = (sel) => [...document.querySelectorAll(sel)];

  const AVAILABLE_COMMANDS = [
    'open [url]',
    'list tabs',
    'switch to tab [n]',
    'close tab',
    'take note [title]: [content]',
    'capture screen',
    'create document [title]',
  ];

  const chatMessages = $('#chatMessages');
  const chatInput    = $('#chatInput');
  const chatSend     = $('#chatSend');

  const noteTitle   = $('#noteTitle');
  const noteContent = $('#noteContent');
  const noteSave    = $('#noteSave');
  const notesList   = $('#notesList');

  const documentsList = $('#documentsList');

  const tabsList    = $('#tabsList');
  const refreshTabs = $('#refreshTabs');

  const screenTitle      = $('#screenTitle');
  const screenUrl        = $('#screenUrl');
  const captureBtn       = $('#captureBtn');
  const refreshScreen    = $('#refreshScreen');
  const screenshotPreview = $('#screenshotPreview');
  const screenshotImg    = $('#screenshotImg');

  // ---------------------------------------------------------------------------
  // Tab Switching
  // ---------------------------------------------------------------------------

  const tabBtns  = $$('.tab-btn');
  const tabPanels = $$('.tab-panel');

  function switchTab(tabName) {
    tabBtns.forEach((b) => b.classList.toggle('active', b.dataset.tab === tabName));
    tabPanels.forEach((p) => p.classList.toggle('active', p.id === `panel-${tabName}`));

    // Auto-refresh data when switching to certain tabs
    if (tabName === 'tabs') loadBrowserTabs();
    if (tabName === 'notes') loadNotes();
    if (tabName === 'documents') loadDocuments();
    if (tabName === 'screen') loadPageInfo();
  }

  tabBtns.forEach((btn) => btn.addEventListener('click', () => switchTab(btn.dataset.tab)));

  // ---------------------------------------------------------------------------
  // Messaging Helper
  // ---------------------------------------------------------------------------

  function sendBg(type, payload = {}) {
    return new Promise((resolve) => {
      chrome.runtime.sendMessage({ type, payload }, (resp) => {
        resolve(resp || { success: false, error: 'No response' });
      });
    });
  }

  // ---------------------------------------------------------------------------
  // Chat
  // ---------------------------------------------------------------------------

  function addChatMsg(text, role = 'jarvis') {
    const div = document.createElement('div');
    div.className = `chat-msg ${role}`;
    div.textContent = text;
    chatMessages.appendChild(div);
    chatMessages.scrollTop = chatMessages.scrollHeight;
  }

  async function handleChatCommand(raw) {
    const input = raw.trim();
    if (!input) return;

    addChatMsg(input, 'user');
    chatInput.value = '';

    const lower = input.toLowerCase();

    // ---- Command Parser ----

    // open [url]
    if (/^open\s+/i.test(input)) {
      let url = input.replace(/^open\s+/i, '').trim();
      if (!/^https?:\/\//i.test(url)) url = 'https://' + url;
      const res = await sendBg('OPEN_URL', { url });
      addChatMsg(res.success ? `Opened ${url}` : `Error: ${res.error}`);
      return;
    }

    // switch to tab [n]
    if (/^switch\s+to\s+tab\s+/i.test(input)) {
      const n = parseInt(input.replace(/^switch\s+to\s+tab\s+/i, ''), 10);
      const listRes = await sendBg('LIST_TABS');
      if (!listRes.success) { addChatMsg(`Error: ${listRes.error}`); return; }
      const target = listRes.tabs[n - 1];
      if (!target) { addChatMsg(`Tab ${n} not found. ${listRes.tabs.length} tabs open.`); return; }
      const switchRes = await sendBg('SWITCH_TAB', { tabId: target.id });
      addChatMsg(switchRes.success ? `Switched to: ${target.title}` : `Error: ${switchRes.error}`);
      return;
    }

    // close tab
    if (/^close\s+tab$/i.test(input)) {
      const infoRes = await sendBg('GET_PAGE_INFO');
      if (!infoRes.success) { addChatMsg(`Error: ${infoRes.error}`); return; }
      const listRes = await sendBg('LIST_TABS');
      const active = listRes.tabs?.find((t) => t.active);
      if (active) {
        await sendBg('CLOSE_TAB', { tabId: active.id });
        addChatMsg(`Closed tab: ${active.title}`);
      } else {
        addChatMsg('No active tab to close.');
      }
      return;
    }

    // list tabs
    if (/^list\s+tabs$/i.test(input)) {
      const res = await sendBg('LIST_TABS');
      if (!res.success) { addChatMsg(`Error: ${res.error}`); return; }
      if (res.tabs.length === 0) { addChatMsg('No tabs open.'); return; }
      const list = res.tabs.map((t, i) => `${i + 1}. ${t.active ? '▸ ' : ''}${t.title}`).join('\n');
      addChatMsg(list);
      return;
    }

    // take note [title]: [content]
    if (/^take\s+note\s+/i.test(input)) {
      const rest = input.replace(/^take\s+note\s+/i, '');
      const colonIdx = rest.indexOf(':');
      let title, content;
      if (colonIdx > -1) {
        title = rest.slice(0, colonIdx).trim();
        content = rest.slice(colonIdx + 1).trim();
      } else {
        title = 'Quick Note';
        content = rest.trim();
      }
      await saveNote(title, content);
      addChatMsg(`Note saved: "${title}"`);
      return;
    }

    // capture screen
    if (/^capture\s+screen$/i.test(input)) {
      addChatMsg('Capturing screenshot…');
      const res = await sendBg('CAPTURE_SCREENSHOT');
      if (res.success) {
        await saveDocument('Screenshot', res.dataUrl);
        addChatMsg('Screenshot captured and saved to Documents.');
      } else {
        addChatMsg(`Capture failed: ${res.error}`);
      }
      return;
    }

    // create document [title]
    if (/^create\s+document\s+/i.test(input)) {
      const title = input.replace(/^create\s+document\s+/i, '').trim();
      await saveDocument(title, null);
      addChatMsg(`Document "${title}" created.`);
      return;
    }

    // Fallback
    addChatMsg(`Command not recognized. Try: ${AVAILABLE_COMMANDS.join(', ')}`);
  }

  chatSend.addEventListener('click', () => handleChatCommand(chatInput.value));
  chatInput.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); handleChatCommand(chatInput.value); }
  });

  // ---------------------------------------------------------------------------
  // Notes CRUD
  // ---------------------------------------------------------------------------

  async function getNotes() {
    const { jarvis_notes = [] } = await chrome.storage.local.get('jarvis_notes');
    return jarvis_notes;
  }

  async function saveNote(title, content) {
    const notes = await getNotes();
    notes.unshift({
      id: crypto.randomUUID(),
      title,
      content,
      createdAt: Date.now(),
    });
    await chrome.storage.local.set({ jarvis_notes: notes });
  }

  async function deleteNote(id) {
    let notes = await getNotes();
    notes = notes.filter((n) => n.id !== id);
    await chrome.storage.local.set({ jarvis_notes: notes });
  }

  async function loadNotes() {
    const notes = await getNotes();
    notesList.innerHTML = '';
    if (notes.length === 0) {
      notesList.innerHTML = '<div class="empty-state">No notes yet. Create one above.</div>';
      return;
    }
    notes.forEach((n) => {
      const card = document.createElement('div');
      card.className = 'card';
      card.innerHTML = `
        <div class="card-title">${escapeHtml(n.title)}</div>
        <div class="card-meta">${new Date(n.createdAt).toLocaleString()}</div>
        <div style="margin-top:6px;font-size:12px;color:var(--text-dim);white-space:pre-wrap;">${escapeHtml(n.content || '')}</div>
        <div class="card-actions">
          <button class="btn btn-danger btn-sm" data-delete-note="${n.id}">Delete</button>
        </div>
      `;
      notesList.appendChild(card);
    });

    notesList.querySelectorAll('[data-delete-note]').forEach((btn) => {
      btn.addEventListener('click', async () => {
        await deleteNote(btn.dataset.deleteNote);
        loadNotes();
      });
    });
  }

  noteSave.addEventListener('click', async () => {
    const title = noteTitle.value.trim();
    const content = noteContent.value.trim();
    if (!title && !content) return;
    await saveNote(title || 'Untitled', content);
    noteTitle.value = '';
    noteContent.value = '';
    loadNotes();
  });

  // ---------------------------------------------------------------------------
  // Documents
  // ---------------------------------------------------------------------------

  async function getDocuments() {
    const { jarvis_documents = [] } = await chrome.storage.local.get('jarvis_documents');
    return jarvis_documents;
  }

  async function saveDocument(title, dataUrl) {
    const docs = await getDocuments();
    docs.unshift({
      id: crypto.randomUUID(),
      title,
      dataUrl,
      type: dataUrl ? 'screenshot' : 'document',
      createdAt: Date.now(),
    });
    await chrome.storage.local.set({ jarvis_documents: docs });
  }

  async function deleteDocument(id) {
    let docs = await getDocuments();
    docs = docs.filter((d) => d.id !== id);
    await chrome.storage.local.set({ jarvis_documents: docs });
  }

  async function loadDocuments() {
    const docs = await getDocuments();
    documentsList.innerHTML = '';
    if (docs.length === 0) {
      documentsList.innerHTML = '<div class="empty-state">No documents yet. Capture a screenshot or create one via chat.</div>';
      return;
    }
    docs.forEach((d) => {
      const card = document.createElement('div');
      card.className = 'card';
      const preview = d.dataUrl
        ? `<div style="margin-top:6px;border-radius:4px;overflow:hidden;border:1px solid var(--border);"><img src="${d.dataUrl}" style="width:100%;display:block;" alt="Capture" /></div>`
        : '';
      card.innerHTML = `
        <div class="card-title">${escapeHtml(d.title)}</div>
        <div class="card-meta">${d.type} · ${new Date(d.createdAt).toLocaleString()}</div>
        ${preview}
        <div class="card-actions">
          ${d.dataUrl ? `<button class="btn btn-ghost btn-sm" data-download-doc="${d.id}">⬇ Download</button>` : ''}
          <button class="btn btn-danger btn-sm" data-delete-doc="${d.id}">Delete</button>
        </div>
      `;
      documentsList.appendChild(card);
    });

    documentsList.querySelectorAll('[data-delete-doc]').forEach((btn) => {
      btn.addEventListener('click', async () => {
        await deleteDocument(btn.dataset.deleteDoc);
        loadDocuments();
      });
    });

    documentsList.querySelectorAll('[data-download-doc]').forEach((btn) => {
      btn.addEventListener('click', async () => {
        const docs = await getDocuments();
        const doc = docs.find((d) => d.id === btn.dataset.downloadDoc);
        if (!doc || !doc.dataUrl) return;
        const a = document.createElement('a');
        a.href = doc.dataUrl;
        a.download = `${doc.title.replace(/[^a-zA-Z0-9_-]+/g, '_').replace(/^_|_$/g, '')}.${doc.type === 'pdf' ? 'pdf' : doc.type === 'doc' ? 'doc' : doc.type === 'txt' ? 'txt' : 'png'}`;
        a.click();
      });
    });
  }

  // ---------------------------------------------------------------------------
  // Browser Tabs
  // ---------------------------------------------------------------------------

  async function loadBrowserTabs() {
    const res = await sendBg('LIST_TABS');
    tabsList.innerHTML = '';
    if (!res.success || !res.tabs.length) {
      tabsList.innerHTML = '<div class="empty-state">No tabs found.</div>';
      return;
    }
    res.tabs.forEach((t) => {
      const card = document.createElement('div');
      card.className = 'card tab-item-card';
      const faviconHtml = t.favIconUrl
        ? `<img class="tab-favicon" src="${t.favIconUrl}" alt="" />`
        : `<div class="tab-favicon" style="background:var(--border);"></div>`;
      card.innerHTML = `
        <div class="tab-item">
          ${faviconHtml}
          <span class="tab-title" title="${escapeHtml(t.url || '')}">${escapeHtml(t.title || 'Untitled')}</span>
          ${t.active ? '<span class="tab-active-badge">ACTIVE</span>' : ''}
        </div>
        <div class="card-actions">
          <button class="btn btn-ghost btn-sm" data-switch-tab="${t.id}">Switch</button>
          <button class="btn btn-danger btn-sm" data-close-tab="${t.id}">Close</button>
        </div>
      `;
      tabsList.appendChild(card);
    });

    tabsList.querySelectorAll('[data-switch-tab]').forEach((btn) => {
      btn.addEventListener('click', async () => {
        await sendBg('SWITCH_TAB', { tabId: parseInt(btn.dataset.switchTab, 10) });
        loadBrowserTabs();
      });
    });

    tabsList.querySelectorAll('[data-close-tab]').forEach((btn) => {
      btn.addEventListener('click', async () => {
        await sendBg('CLOSE_TAB', { tabId: parseInt(btn.dataset.closeTab, 10) });
        loadBrowserTabs();
      });
    });
  }

  refreshTabs.addEventListener('click', loadBrowserTabs);

  // ---------------------------------------------------------------------------
  // Screen
  // ---------------------------------------------------------------------------

  async function loadPageInfo() {
    const res = await sendBg('GET_PAGE_INFO');
    if (res.success) {
      screenTitle.textContent = res.info.title || '—';
      screenUrl.textContent = res.info.url || '—';
    }
  }

  captureBtn.addEventListener('click', async () => {
    captureBtn.disabled = true;
    captureBtn.textContent = 'Capturing…';
    const res = await sendBg('CAPTURE_SCREENSHOT');
    if (res.success) {
      screenshotImg.src = res.dataUrl;
      screenshotPreview.style.display = 'block';
      await saveDocument(`Screenshot ${new Date().toLocaleString()}`, res.dataUrl);
    } else {
      addChatMsg(`Screenshot failed: ${res.error}`);
    }
    captureBtn.disabled = false;
    captureBtn.textContent = '📷 Capture Screenshot';
  });

  refreshScreen.addEventListener('click', loadPageInfo);

  // ---------------------------------------------------------------------------
  // Utilities
  // ---------------------------------------------------------------------------

  function escapeHtml(str) {
    const el = document.createElement('span');
    el.textContent = str;
    return el.innerHTML;
  }

  // ---------------------------------------------------------------------------
  // Init
  // ---------------------------------------------------------------------------

  loadNotes();
  loadDocuments();
  loadPageInfo();
})();
