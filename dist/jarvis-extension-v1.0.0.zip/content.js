// JARVIS — Content Script

(function () {
  'use strict';

  // Prevent double-injection
  if (document.getElementById('jarvis-fab')) return;

  // ---------------------------------------------------------------------------
  // Floating Action Button
  // ---------------------------------------------------------------------------

  const fab = document.createElement('button');
  fab.id = 'jarvis-fab';
  fab.textContent = 'J';
  fab.setAttribute('aria-label', 'Open JARVIS side panel');
  fab.classList.add('jarvis-pulse');
  document.body.appendChild(fab);

  // Remove pulse animation after it finishes
  fab.addEventListener('animationend', () => {
    fab.classList.remove('jarvis-pulse');
  });

  fab.addEventListener('click', () => {
    chrome.runtime.sendMessage({ type: 'OPEN_SIDE_PANEL' }).catch(() => {
      // Side panel API may not support opening from content script context —
      // the background handler will take care of it.
    });
  });

  // ---------------------------------------------------------------------------
  // Helpers
  // ---------------------------------------------------------------------------

  function getSelectedText() {
    const selection = window.getSelection();
    return selection ? selection.toString().trim() : '';
  }

  function getPageData() {
    return {
      title: document.title,
      url: window.location.href,
      selectedText: getSelectedText(),
    };
  }

  // ---------------------------------------------------------------------------
  // Message Listeners
  // ---------------------------------------------------------------------------

  chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    switch (message.type) {
      case 'GET_SELECTION':
        sendResponse({ success: true, selectedText: getSelectedText() });
        break;

      case 'GET_PAGE_DATA':
        sendResponse({ success: true, data: getPageData() });
        break;

      default:
        sendResponse({ success: false, error: 'Unknown content message type' });
    }
    return false; // synchronous response
  });
})();
