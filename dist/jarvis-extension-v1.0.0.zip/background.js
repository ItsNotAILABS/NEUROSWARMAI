// JARVIS — Background Service Worker (Manifest V3)

// ---------------------------------------------------------------------------
// Side Panel — open on action click
// ---------------------------------------------------------------------------

chrome.action.onClicked.addListener(async (tab) => {
  try {
    await chrome.sidePanel.open({ tabId: tab.id });
  } catch (err) {
    console.error('[JARVIS] Failed to open side panel:', err);
  }
});

// ---------------------------------------------------------------------------
// Heartbeat — persist status every 30 seconds
// ---------------------------------------------------------------------------

const HEARTBEAT_INTERVAL_MS = 30_000;

async function heartbeat() {
  try {
    await chrome.storage.local.set({
      jarvis_heartbeat: {
        status: 'alive',
        timestamp: Date.now(),
        version: chrome.runtime.getManifest().version,
      },
    });
  } catch (err) {
    console.error('[JARVIS] Heartbeat error:', err);
  }
}

setInterval(heartbeat, HEARTBEAT_INTERVAL_MS);
heartbeat();

// ---------------------------------------------------------------------------
// Command History helpers
// ---------------------------------------------------------------------------

async function pushCommandHistory(entry) {
  const { jarvis_commands = [] } = await chrome.storage.local.get('jarvis_commands');
  jarvis_commands.push({ ...entry, timestamp: Date.now() });
  // Keep last 200 entries
  if (jarvis_commands.length > 200) jarvis_commands.splice(0, jarvis_commands.length - 200);
  await chrome.storage.local.set({ jarvis_commands });
}

// ---------------------------------------------------------------------------
// Message Router
// ---------------------------------------------------------------------------

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  handleMessage(message, sender)
    .then(sendResponse)
    .catch((err) => sendResponse({ success: false, error: err.message }));
  return true; // keep channel open for async response
});

async function handleMessage(msg, _sender) {
  const { type, payload } = msg;

  switch (type) {
    // ---- Tab commands -----------------------------------------------------
    case 'LIST_TABS': {
      const tabs = await chrome.tabs.query({});
      const mapped = tabs.map((t) => ({
        id: t.id,
        title: t.title,
        url: t.url,
        active: t.active,
        windowId: t.windowId,
        favIconUrl: t.favIconUrl,
        index: t.index,
      }));
      await pushCommandHistory({ type: 'LIST_TABS' });
      return { success: true, tabs: mapped };
    }

    case 'SWITCH_TAB': {
      const { tabId } = payload;
      await chrome.tabs.update(tabId, { active: true });
      const tab = await chrome.tabs.get(tabId);
      await chrome.windows.update(tab.windowId, { focused: true });
      await pushCommandHistory({ type: 'SWITCH_TAB', tabId });
      return { success: true };
    }

    case 'CLOSE_TAB': {
      const { tabId } = payload;
      await chrome.tabs.remove(tabId);
      await pushCommandHistory({ type: 'CLOSE_TAB', tabId });
      return { success: true };
    }

    case 'CREATE_TAB': {
      const { url } = payload;
      const tab = await chrome.tabs.create({ url });
      await pushCommandHistory({ type: 'CREATE_TAB', url });
      return { success: true, tabId: tab.id };
    }

    case 'OPEN_URL': {
      const { url } = payload;
      const tab = await chrome.tabs.create({ url, active: true });
      await pushCommandHistory({ type: 'OPEN_URL', url });
      return { success: true, tabId: tab.id };
    }

    // ---- Screenshot -------------------------------------------------------
    case 'CAPTURE_SCREENSHOT': {
      const [activeTab] = await chrome.tabs.query({ active: true, currentWindow: true });
      if (!activeTab) return { success: false, error: 'No active tab' };
      const dataUrl = await chrome.tabs.captureVisibleTab(activeTab.windowId, {
        format: 'png',
      });
      await pushCommandHistory({ type: 'CAPTURE_SCREENSHOT' });
      return { success: true, dataUrl };
    }

    // ---- Page info --------------------------------------------------------
    case 'GET_PAGE_INFO': {
      const [activeTab] = await chrome.tabs.query({ active: true, currentWindow: true });
      if (!activeTab) return { success: false, error: 'No active tab' };
      await pushCommandHistory({ type: 'GET_PAGE_INFO' });
      return {
        success: true,
        info: {
          title: activeTab.title,
          url: activeTab.url,
          favIconUrl: activeTab.favIconUrl,
        },
      };
    }

    // ---- Open side panel (from content script FAB) -------------------------
    case 'OPEN_SIDE_PANEL': {
      const [activeTab] = await chrome.tabs.query({ active: true, currentWindow: true });
      if (activeTab) {
        await chrome.sidePanel.open({ tabId: activeTab.id });
      }
      return { success: true };
    }

    default:
      return { success: false, error: `Unknown message type: ${type}` };
  }
}
